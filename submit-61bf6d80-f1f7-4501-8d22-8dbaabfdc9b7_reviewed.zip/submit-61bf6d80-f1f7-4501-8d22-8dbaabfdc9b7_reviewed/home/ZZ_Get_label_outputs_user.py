from os import listdir

# TODO 2: Define get_pet_labels function below please be certain to replace None
#       in the return statement with results_dic dictionary that you create 
#       with this function
# 


results_dic = {}
    
filename_list = listdir("pet_images/")

pet_names = []

num_dogs = len(filename_list)

for dog in filename_list:
    
    pet_image = dog
    low_pet_image = pet_image.lower()
    word_list_pet_image = low_pet_image.split("_")
    pet_name = ""
    
    for word in word_list_pet_image:
        if word.isalpha():
            pet_name += word + " "
            
    pet_name = pet_name.strip()
    pet_names.append(pet_name)
            
for i in range(0, num_dogs):
    if filename_list[i] not in results_dic:
        results_dic[filename_list[i]] = [pet_names[i]]
        
    else:
        print("** Warning!!: Key = ", filesname_list[i], "already exist in results_dic with name = ", results_dic[filename_list[i]])
        
#    for key in results_dic:
#        print("File_name = ", key, "- pet_label = ", results_dic[key][0])
 
   
    # Replace None with the results_dic dictionary that you created with this
    # functio
print(results_dic)