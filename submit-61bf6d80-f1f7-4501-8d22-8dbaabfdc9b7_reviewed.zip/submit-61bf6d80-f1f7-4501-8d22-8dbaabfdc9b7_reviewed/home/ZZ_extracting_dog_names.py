dog_names_lines = []

f = open("dognames.txt", "r")


dog_names_lines = f.readlines()
pet_images_labels = []
         
print(dog_names_lines)