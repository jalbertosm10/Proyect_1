
from classifier import classifier 
from os import listdir

# Defines a dog test image from pet_images folder
test_image='imagenet1000_clsid_to_human.txt'

# Defines a model architecture to be used for classification
# NOTE: this function only works for model architectures: 
#      'vgg', 'alexnet', 'resnet'  
model = "vgg"

# Demonstrates classifier() functions usage
# NOTE: image_classication is a text string - It contains mixed case(both lower
# and upper case letter) image labels that can be separated by commas when a 
# label has more than one word that can describe it.
filename_list = listdir("pet_images/")

classifier_labels = []

for filename in filename_list:
    
    image_classification = classifier("pet_images/" + filename, model)
    image_classification = image_classification.lower()
    classifier_labels.append(image_classification)
            
        
print(classifier_labels)    
#print(len(classifier_labels))
            