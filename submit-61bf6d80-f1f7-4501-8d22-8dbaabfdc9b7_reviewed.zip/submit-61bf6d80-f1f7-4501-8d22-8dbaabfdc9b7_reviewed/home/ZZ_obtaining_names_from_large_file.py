
pet_images_lines = []

f = open("imagenet1000_clsid_to_human.txt", "r")


pet_images_lines = f.readlines()
pet_images_labels = []
         
for line in pet_images_lines:
    
    line_useful = line.replace("'", " ")
    line_useful = line_useful.replace(",", " ")
    line_lower = line_useful.lower()
    words = line_lower.split(" ")
    
    pet_image_line = ""
    
    for word in words:
        if word.isalpha():
            pet_image_line += word + " "
        
    pet_image_line = pet_image_line.strip()
    
    pet_images_labels.append(pet_image_line)
    
print(pet_images_labels)

    
    
    