

### Todo esto se hace para importar "results_dic" para este srcip a modo de chequear el código

from classifier import classifier 
#from os import listdir
# TODO 3: Define classify_images function below, specifically replace the None
#       below by the function definition of the classify_images function. 
#       Notice that this function doesn't return anything because the 
#       results_dic dictionary that is passed into the function is a mutable 
#       data type so no return is needed.
# 
      #!/usr/bin/env python3
# -*- coding: utf-8 -*-
# */AIPND-revision/intropyproject-classify-pet-images/get_pet_labels.py
#                                                                             
# PROGRAMMER: Jesús Alberto Sánchez Medina
# DATE CREATED: 23/09/2020                                  
# REVISED DATE: 
# PURPOSE: Create the function get_pet_labels that creates the pet labels from 
#          the image's filename. This function inputs: 
#           - The Image Folder as image_dir within get_pet_labels function and 
#             as in_arg.dir for the function call within the main function. 
#          This function creates and returns the results dictionary as results_dic
#          within get_pet_labels function and as results within main. 
#          The results_dic dictionary has a 'key' that's the image filename and
#          a 'value' that's a list. This list will contain the following item
#          at index 0 : pet image label (string).
#
##
# Imports python modules
from os import listdir

# TODO 2: Define get_pet_labels function below please be certain to replace None
#       in the return statement with results_dic dictionary that you create 
#       with this function
# 
def get_pet_labels(image_dir):
    """
    Creates a dictionary of pet labels (results_dic) based upon the filenames 
    of the image files. These pet image labels are used to check the accuracy 
    of the labels that are returned by the classifier function, since the 
    filenames of the images contain the true identity of the pet in the image.
    Be sure to format the pet labels so that they are in all lower case letters
    and with leading and trailing whitespace characters stripped from them.
    (ex. filename = 'Boston_terrier_02259.jpg' Pet label = 'boston terrier')
    Parameters:
     image_dir - The (full) path to the folder of images that are to be
                 classified by the classifier function (string)
    Returns:
      results_dic - Dictionary with 'key' as image filename and 'value' as a 
      List. The list contains for following item:
         index 0 = pet image label (string)
    """
    results_dic = {}
    
    filename_list = listdir(image_dir)

    pet_names = []

    num_dogs = len(filename_list)

    for dog in filename_list:
    
        pet_image = dog
        low_pet_image = pet_image.lower()
        word_list_pet_image = low_pet_image.split("_")
        pet_name = ""
    
        for word in word_list_pet_image:
            if word.isalpha():
                pet_name += word + " "
            
        pet_name = pet_name.strip()
        pet_names.append(pet_name)
            
    for i in range(0, num_dogs):
        if filename_list[i] not in results_dic:
            results_dic[filename_list[i]] = [pet_names[i]]
        
        else:
            print("** Warning!!: Key = ", filesname_list[i], "already exist in results_dic with name = ", results_dic[filename_list[i]])
        
#    for key in results_dic:
#        print("File_name = ", key, "- pet_label = ", results_dic[key][0])
 
   
    # Replace None with the results_dic dictionary that you created with this
    # function
    return results_dic 

results_dic = get_pet_labels("pet_images/")

#print(results_dic)

model = 'vgg'

filename_list = listdir("pet_images/")

classifier_labels = []

for filename in filename_list:
    
    image_classification = classifier("pet_images/" + filename, model)
    image_classification = image_classification.lower()
    classifier_labels.append(image_classification)
            
        
    #print(classifier_labels)    
    
for idx in range(0, len(filename_list), 1):
        
    if filename_list[idx] in results_dic:
        results_dic[filename_list[idx]].append(classifier_labels[idx])

#print(results_dic)         

for idx in results_dic:
    
    if results_dic[idx][0] in results_dic[idx][1]:    
        
        results_dic[idx].append(1)
                                                         
    else:
        
        results_dic[idx].append(0)

#print(results_dic)

#for key in results_dic:
#    print("\nFilename=", key, "\npet_image Label=", results_dic[key][0],
#          "\nClassifier Label=", results_dic[key][1],
#          "\nIf 1, labels match; if 0, labels do not match=", results_dic[key][2])  
                                                          
    
#print(results_dic[filename_list[0].[0]])



dog_names_lines = {}
dogs_dic = {}
f = open("dognames.txt", "r")


dog_names_lines = f.readlines()

for line in dog_names_lines:
    line = line.rstrip('\n')
    dogs_dic[line] = 1
    
#for key, value in dogs_dic:
#    dogs_dic[str(key)].rstrip('\n')
    
print(dogs_dic)    

           
for i in results_dic:
    if results_dic[i][0] in dogs_dic:
        results_dic[i].append(1)
    else:
        results_dic[i].append(0)
    
for i in results_dic:
                              
    if results_dic[i][1] in dogs_dic:
        results_dic[i].append(1)
    else:
        results_dic[i].append(0)                             

print("change\n\n")
#print(dog_names_lines)   

print("change\n\n")
#print(final_dog_names)
print("change\n\n")
print(results_dic)   

print("change\n\n")
####### El trabajo comienza a partir de aquí, lo anterior es para obtener results_dic

results_stats_dic = dict()

#            n_images - number of images
#            n_dogs_img - number of dog images
#            n_notdogs_img - number of NON-dog images

#            n_match - number of matches between pet & classifier labels
#            n_correct_dogs - number of correctly classified dog images
#            n_correct_notdogs - number of correctly classified NON-dog images
#            n_correct_breed - number of correctly classified dog breeds
#            pct_match - percentage of correct matches
#            pct_correct_dogs - percentage of correctly classified dogs
#            pct_correct_breed - percentage of correctly classified dog breeds
#            pct_correct_notdogs - percentage of correctly classified NON-dogs

results_stats_dic['n_images'] = 0
results_stats_dic['n_dogs_img'] = 0
results_stats_dic['n_notdogs_img'] = 0
results_stats_dic['n_match'] = 0
results_stats_dic['n_correct_dogs'] = 0
results_stats_dic['n_correct_notdogs'] = 0
results_stats_dic['n_correct_breed'] = 0

results_stats_dic['pct_match'] = 0.0
results_stats_dic['pct_correct_dogs'] = 0.0
results_stats_dic['pct_correct_breed'] = 0.0
results_stats_dic['pct_correct_notdogs'] = 0.0

results_stats_dic['n_images'] = len(results_dic)

for key in results_dic:
    
    if results_dic[key][3] == 1:
        results_stats_dic['n_dogs_img'] += 1
        
    if results_dic[key][3] == 0:
        results_stats_dic['n_notdogs_img'] += 1
        
    if results_dic[key][2] == 1:
        results_stats_dic['n_match'] += 1
        
    if results_dic[key][4] == 1:
        results_stats_dic['n_correct_dogs'] += 1
        
    if results_dic[key][4] == 0:
        results_stats_dic['n_correct_notdogs'] += 1    
        
    if results_dic[key][3] == 1 and results_dic[key][4] == 1:
        results_stats_dic['n_correct_breed'] += 1
        
results_stats_dic['pct_match'] = (results_stats_dic['n_correct_dogs'] / results_stats_dic['n_dogs_img']) * 100

results_stats_dic['pct_correct_dogs'] = (results_stats_dic['n_correct_dogs'] / results_stats_dic['n_dogs_img']) * 100

results_stats_dic['pct_correct_notdogs'] = (results_stats_dic['n_correct_notdogs'] / results_stats_dic['n_dogs_img']) * 100

results_stats_dic['pct_correct_breed'] = (results_stats_dic['n_correct_breed'] / results_stats_dic['n_dogs_img']) * 100


print(results_stats_dic)