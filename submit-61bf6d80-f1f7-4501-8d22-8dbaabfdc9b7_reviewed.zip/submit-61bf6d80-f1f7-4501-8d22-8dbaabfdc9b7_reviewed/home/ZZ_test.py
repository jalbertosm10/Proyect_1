dog_names_lines = {}
dogs_dic = {}
f = open("dognames.txt", "r")


dog_names_lines = f.readlines()

for line in dog_names_lines:
    line = line.rstrip('\n')
    dogs_dic[line] = 1
    
#for key, value in dogs_dic:
#    dogs_dic[str(key)].rstrip('\n')
    
print(dogs_dic)    

print(dog_names_lines)

    #line.rstrip('\n')
#    final_dog_names += line
    
#print(dog_names_lines)    
#print(final_dog_names)